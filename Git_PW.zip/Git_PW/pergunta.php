<!DOCTYPE html>
<html lang="pt-br">
<head>
                 <meta charset="UTF-8">
         <title>Document</title>
</head>
<body>
        <form action="resposta.php" method="GET">
        

            <input type="date" name = "v1" Placeholder="Digite a primeira data">

            <input type="date" name = v2 Placeholder="Digite a segunda data">
        <input type="submit" name="" value="Resposta">
    </form>
    
</body>
</html>